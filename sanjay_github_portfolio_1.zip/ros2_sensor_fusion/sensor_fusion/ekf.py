"""Extended Kalman Filter for 2D differential-drive localization.

State vector:  [x, y, theta, v, omega]
    x, y     world position (m)
    theta    heading (rad)
    v        linear velocity (m/s)
    omega    yaw rate (rad/s)

Motion model is a constant-velocity prediction. Two measurement sources are
fused:
    * wheel odometry  -> observes (v, omega)
    * IMU             -> observes (omega)

The core is plain NumPy with no ROS dependency, so it can be unit-tested and
reused outside a robot stack.
"""
from __future__ import annotations

import numpy as np


def wrap_angle(a: float) -> float:
    """Wrap an angle to (-pi, pi]."""
    return (a + np.pi) % (2.0 * np.pi) - np.pi


class EKF:
    def __init__(self, process_noise: np.ndarray | None = None) -> None:
        self.x = np.zeros(5)                 # state estimate
        self.P = np.eye(5) * 0.1             # covariance
        # Continuous-ish process noise spectral densities, scaled by dt.
        self.Q = (
            process_noise
            if process_noise is not None
            else np.diag([0.01, 0.01, 0.01, 0.5, 0.5])
        )

    # ------------------------------------------------------------------ predict
    def predict(self, dt: float) -> None:
        x, y, th, v, w = self.x

        # Nonlinear motion model.
        self.x = np.array(
            [
                x + v * np.cos(th) * dt,
                y + v * np.sin(th) * dt,
                wrap_angle(th + w * dt),
                v,
                w,
            ]
        )

        # Jacobian of the motion model wrt state.
        F = np.eye(5)
        F[0, 2] = -v * np.sin(th) * dt
        F[0, 3] = np.cos(th) * dt
        F[1, 2] = v * np.cos(th) * dt
        F[1, 3] = np.sin(th) * dt
        F[2, 4] = dt

        self.P = F @ self.P @ F.T + self.Q * dt

    # ------------------------------------------------------------------- update
    def _update(self, z: np.ndarray, H: np.ndarray, R: np.ndarray) -> None:
        y_res = z - H @ self.x
        S = H @ self.P @ H.T + R
        K = self.P @ H.T @ np.linalg.inv(S)
        self.x = self.x + K @ y_res
        self.x[2] = wrap_angle(self.x[2])
        self.P = (np.eye(5) - K @ H) @ self.P

    def update_odometry(self, v_meas: float, w_meas: float, R: np.ndarray) -> None:
        """Fuse a wheel-odometry twist measurement of (v, omega)."""
        H = np.zeros((2, 5))
        H[0, 3] = 1.0   # v
        H[1, 4] = 1.0   # omega
        self._update(np.array([v_meas, w_meas]), H, R)

    def update_imu(self, w_meas: float, r: float) -> None:
        """Fuse an IMU yaw-rate measurement of omega."""
        H = np.zeros((1, 5))
        H[0, 4] = 1.0
        self._update(np.array([w_meas]), H, np.array([[r]]))

    # -------------------------------------------------------------- convenience
    @property
    def pose(self) -> tuple[float, float, float]:
        return float(self.x[0]), float(self.x[1]), float(self.x[2])
