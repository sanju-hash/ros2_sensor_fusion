"""ROS 2 node that fuses /odom and /imu into a filtered pose on /odom_filtered.

Subscribes:
    /odom  (nav_msgs/Odometry)      -> twist (v, omega)
    /imu   (sensor_msgs/Imu)        -> angular_velocity.z (yaw rate)

Publishes:
    /odom_filtered (nav_msgs/Odometry)   filtered pose + twist
    TF: odom -> base_link

Run with the bundled simulator (no hardware needed):
    ros2 launch sensor_fusion fusion.launch.py
"""
from __future__ import annotations

import math

import rclpy
from geometry_msgs.msg import TransformStamped
from nav_msgs.msg import Odometry
from rclpy.node import Node
from sensor_msgs.msg import Imu
from tf2_ros import TransformBroadcaster

from .ekf import EKF


def yaw_to_quaternion(yaw: float):
    return (0.0, 0.0, math.sin(yaw / 2.0), math.cos(yaw / 2.0))


class EkfFusionNode(Node):
    def __init__(self) -> None:
        super().__init__("ekf_fusion_node")

        self.declare_parameter("odom_v_var", 0.05)
        self.declare_parameter("odom_w_var", 0.05)
        self.declare_parameter("imu_w_var", 0.02)

        self.ekf = EKF()
        self.last_time = self.get_clock().now()

        self.create_subscription(Odometry, "odom", self._on_odom, 20)
        self.create_subscription(Imu, "imu", self._on_imu, 50)
        self.pub = self.create_publisher(Odometry, "odom_filtered", 10)
        self.tf_broadcaster = TransformBroadcaster(self)

        # Run the filter at a fixed rate independent of sensor arrival.
        self.create_timer(0.02, self._tick)
        self.get_logger().info("EKF fusion node started")

    def _dt(self) -> float:
        now = self.get_clock().now()
        dt = (now - self.last_time).nanoseconds * 1e-9
        self.last_time = now
        return max(dt, 1e-3)

    def _on_odom(self, msg: Odometry) -> None:
        import numpy as np

        v = msg.twist.twist.linear.x
        w = msg.twist.twist.angular.z
        var_v = self.get_parameter("odom_v_var").value
        var_w = self.get_parameter("odom_w_var").value
        self.ekf.update_odometry(v, w, np.diag([var_v, var_w]))

    def _on_imu(self, msg: Imu) -> None:
        w = msg.angular_velocity.z
        self.ekf.update_imu(w, self.get_parameter("imu_w_var").value)

    def _tick(self) -> None:
        self.ekf.predict(self._dt())
        self._publish()

    def _publish(self) -> None:
        x, y, th = self.ekf.pose
        qx, qy, qz, qw = yaw_to_quaternion(th)
        now = self.get_clock().now().to_msg()

        out = Odometry()
        out.header.stamp = now
        out.header.frame_id = "odom"
        out.child_frame_id = "base_link"
        out.pose.pose.position.x = x
        out.pose.pose.position.y = y
        out.pose.pose.orientation.z = qz
        out.pose.pose.orientation.w = qw
        out.twist.twist.linear.x = float(self.ekf.x[3])
        out.twist.twist.angular.z = float(self.ekf.x[4])
        self.pub.publish(out)

        tf = TransformStamped()
        tf.header.stamp = now
        tf.header.frame_id = "odom"
        tf.child_frame_id = "base_link"
        tf.transform.translation.x = x
        tf.transform.translation.y = y
        tf.transform.rotation.z = qz
        tf.transform.rotation.w = qw
        self.tf_broadcaster.sendTransform(tf)


def main(args=None) -> None:
    rclpy.init(args=args)
    node = EkfFusionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
