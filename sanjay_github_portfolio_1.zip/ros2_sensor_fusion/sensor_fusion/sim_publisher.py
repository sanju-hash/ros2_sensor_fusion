"""Publishes simulated /odom and /imu for a robot driving a figure-of-eight.

Lets you run and visualise the EKF fusion node without any real robot.
"""
from __future__ import annotations

import math
import random

import rclpy
from nav_msgs.msg import Odometry
from rclpy.node import Node
from sensor_msgs.msg import Imu


class SimPublisher(Node):
    def __init__(self) -> None:
        super().__init__("sim_publisher")
        self.odom_pub = self.create_publisher(Odometry, "odom", 10)
        self.imu_pub = self.create_publisher(Imu, "imu", 10)
        self.t = 0.0
        self.dt = 0.02
        self.create_timer(self.dt, self._tick)
        self.get_logger().info("Simulator publishing /odom and /imu")

    def _tick(self) -> None:
        self.t += self.dt
        # Figure-of-eight: sinusoidal yaw rate, roughly constant speed.
        v = 0.6
        w = 0.8 * math.sin(0.3 * self.t)
        now = self.get_clock().now().to_msg()

        odom = Odometry()
        odom.header.stamp = now
        odom.header.frame_id = "odom"
        odom.twist.twist.linear.x = v + random.gauss(0, 0.04)
        odom.twist.twist.angular.z = w + random.gauss(0, 0.04)
        self.odom_pub.publish(odom)

        imu = Imu()
        imu.header.stamp = now
        imu.header.frame_id = "imu_link"
        imu.angular_velocity.z = w + random.gauss(0, 0.015)
        self.imu_pub.publish(imu)


def main(args=None) -> None:
    rclpy.init(args=args)
    node = SimPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
