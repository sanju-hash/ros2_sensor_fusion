"""Launch the simulator and the EKF fusion node together."""
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription(
        [
            Node(
                package="sensor_fusion",
                executable="sim_publisher",
                name="sim_publisher",
                output="screen",
            ),
            Node(
                package="sensor_fusion",
                executable="ekf_node",
                name="ekf_fusion_node",
                output="screen",
            ),
        ]
    )
