# ROS 2 Sensor Fusion (EKF)

An Extended Kalman Filter ROS 2 package that fuses **wheel odometry** and **IMU**
into a smooth, drift-reduced 2D pose estimate for a differential-drive robot.
Built with `rclpy` (ROS 2 Humble), with the filter core written as plain NumPy
so it is unit-testable and reusable independent of ROS.

State estimated: `[x, y, theta, v, omega]`.

## Why

Wheel odometry drifts; IMU yaw is locally accurate but biased over time. Fusing
them in an EKF gives a pose estimate better than either alone — the standard
front-end to a localization or SLAM stack on an autonomous mobile robot.

## Topics

| Direction | Topic            | Type                  | Notes                         |
|-----------|------------------|-----------------------|-------------------------------|
| sub       | `/odom`          | `nav_msgs/Odometry`   | twist used: `v`, `omega`      |
| sub       | `/imu`           | `sensor_msgs/Imu`     | uses `angular_velocity.z`     |
| pub       | `/odom_filtered` | `nav_msgs/Odometry`   | fused pose + twist            |
| TF        | `odom -> base_link` |                    | broadcast each tick           |

## Quick start

Build in a ROS 2 (Humble) workspace:

```bash
mkdir -p ~/ws/src && cd ~/ws/src
git clone https://github.com/<your-username>/ros2_sensor_fusion.git sensor_fusion
cd ~/ws
colcon build --packages-select sensor_fusion
source install/setup.bash
```

Run the EKF together with the built-in simulator (no hardware required):

```bash
ros2 launch sensor_fusion fusion.launch.py
```

Inspect the output:

```bash
ros2 topic echo /odom_filtered
# or visualise the odom -> base_link TF in RViz2
```

The simulator drives a figure-of-eight and publishes noisy `/odom` and `/imu`;
the filter recovers a smooth trajectory.

## Filter design

- **Predict:** nonlinear constant-velocity motion model with analytic Jacobian.
- **Update (odometry):** observes `(v, omega)`.
- **Update (IMU):** observes `omega` (yaw rate).
- Angles are wrapped to `(-pi, pi]` after every step.
- Process and measurement noise are tunable; odometry/IMU variances are ROS
  parameters (`odom_v_var`, `odom_w_var`, `imu_w_var`).

## Tests

The filter core runs without ROS:

```bash
pytest test/ -q
```

Covered: angle wrapping, straight-line prediction, convergence on a noisy
circular trajectory (tracks within 25 cm; recovers `v` and `omega`), and
covariance stability.

## Extending

- Add a `LiDAR` scan-match or AMCL pose as a third `(x, y, theta)` measurement
  update for full global correction.
- Promote to 3D (`x, y, z, roll, pitch, yaw`) by extending the state and
  Jacobians.

## License

MIT — see [LICENSE](LICENSE).
