from setuptools import find_packages, setup

package_name = "sensor_fusion"

setup(
    name=package_name,
    version="0.1.0",
    packages=find_packages(exclude=["test"]),
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
        ("share/" + package_name, ["package.xml"]),
        ("share/" + package_name + "/launch", ["launch/fusion.launch.py"]),
    ],
    install_requires=["setuptools", "numpy"],
    zip_safe=True,
    maintainer="Sanjay Kumar",
    maintainer_email="sanjayshekhar2000@gmail.com",
    description="EKF fusion of wheel odometry and IMU for 2D localization.",
    license="MIT",
    entry_points={
        "console_scripts": [
            "ekf_node = sensor_fusion.ekf_node:main",
            "sim_publisher = sensor_fusion.sim_publisher:main",
        ],
    },
)
