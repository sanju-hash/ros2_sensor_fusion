"""Tests for the EKF core. Run with: pytest -q  (no ROS needed)"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from sensor_fusion.ekf import EKF, wrap_angle  # noqa: E402


def test_wrap_angle():
    assert abs(wrap_angle(3 * np.pi)) - np.pi < 1e-9
    assert abs(wrap_angle(0.0)) < 1e-9


def test_straight_line_prediction():
    ekf = EKF()
    ekf.x = np.array([0.0, 0.0, 0.0, 1.0, 0.0])  # heading +x, 1 m/s
    for _ in range(10):
        ekf.predict(0.1)
    x, y, _ = ekf.pose
    assert abs(x - 1.0) < 0.05   # ~1 m travelled
    assert abs(y) < 1e-6


def test_fusion_converges_on_circle():
    np.random.seed(1)
    dt = 0.05
    ekf = EKF()
    true = np.zeros(3)
    v_true, w_true = 0.5, 0.3
    for _ in range(300):
        true[0] += v_true * np.cos(true[2]) * dt
        true[1] += v_true * np.sin(true[2]) * dt
        true[2] = wrap_angle(true[2] + w_true * dt)
        ekf.predict(dt)
        ekf.update_odometry(
            v_true + np.random.randn() * 0.05,
            w_true + np.random.randn() * 0.05,
            np.diag([0.05, 0.05]),
        )
        ekf.update_imu(w_true + np.random.randn() * 0.02, 0.02)

    err = np.hypot(ekf.x[0] - true[0], ekf.x[1] - true[1])
    assert err < 0.25           # tracks within 25 cm
    assert abs(ekf.x[3] - v_true) < 0.1
    assert abs(ekf.x[4] - w_true) < 0.1


def test_covariance_stays_finite():
    ekf = EKF()
    for _ in range(100):
        ekf.predict(0.05)
    assert np.all(np.isfinite(ekf.P))
