"""Perception pipeline tying obstacle detection and plant analysis together.

Runs both analyzers over a frame and produces a combined annotated image plus a
structured result that a navigation/control layer could consume.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np

from .obstacle_detector import Obstacle, ObstacleDetector
from .plant_analyzer import PlantAnalyzer, PlantReport


@dataclass
class FrameResult:
    obstacles: list[Obstacle]
    plant: PlantReport

    def to_dict(self) -> dict:
        return {
            "obstacle_count": len(self.obstacles),
            "obstacles": [asdict(o) for o in self.obstacles],
            "vegetation_fraction": round(self.plant.vegetation_fraction, 4),
            "mean_greenness": round(self.plant.mean_greenness, 4),
            "health_label": self.plant.health_label,
        }


class PerceptionPipeline:
    def __init__(
        self,
        obstacle_detector: ObstacleDetector | None = None,
        plant_analyzer: PlantAnalyzer | None = None,
    ) -> None:
        self.obstacles = obstacle_detector or ObstacleDetector()
        self.plants = plant_analyzer or PlantAnalyzer()

    def process(self, bgr: np.ndarray) -> FrameResult:
        plant = self.plants.analyze(bgr)
        # Crop vegetation is not a collision obstacle -- exclude it.
        obstacles = self.obstacles.detect(bgr, exclude_mask=plant.mask)
        return FrameResult(obstacles=obstacles, plant=plant)

    def annotate(self, bgr: np.ndarray, result: FrameResult) -> np.ndarray:
        out = self.plants.overlay(bgr, result.plant)
        out = self.obstacles.draw(out, result.obstacles)
        return out
