"""Plant condition analysis from RGB imagery.

Computes an RGB-based vegetation index (Excess Green, ExG) and segments
vegetation from background. Useful in precision-agriculture AMRs where a
ground robot inspects crop rows with a standard RGB camera (no NIR band).

Reference: Woebbecke et al. (1995), "Color indices for weed identification".
"""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np


@dataclass
class PlantReport:
    """Summary of vegetation condition for a single frame."""

    vegetation_fraction: float          # share of pixels classified as plant [0..1]
    mean_greenness: float               # mean ExG over vegetation pixels
    health_label: str                   # "healthy" | "stressed" | "sparse"
    mask: np.ndarray                    # uint8 binary mask of vegetation


class PlantAnalyzer:
    """Detect vegetation and estimate a coarse health label from an RGB frame."""

    def __init__(
        self,
        exg_threshold: float = 0.10,
        healthy_greenness: float = 0.25,
        min_vegetation_fraction: float = 0.05,
    ) -> None:
        self.exg_threshold = exg_threshold
        self.healthy_greenness = healthy_greenness
        self.min_vegetation_fraction = min_vegetation_fraction

    @staticmethod
    def _excess_green(bgr: np.ndarray) -> np.ndarray:
        """Excess Green index: 2g - r - b on chromatic-normalised channels."""
        img = bgr.astype(np.float32) / 255.0
        b, g, r = cv2.split(img)
        total = r + g + b + 1e-6
        r_n, g_n, b_n = r / total, g / total, b / total
        return 2.0 * g_n - r_n - b_n

    def analyze(self, bgr: np.ndarray) -> PlantReport:
        if bgr is None or bgr.size == 0:
            raise ValueError("analyze() received an empty image")

        exg = self._excess_green(bgr)
        mask = (exg > self.exg_threshold).astype(np.uint8)

        # Clean up speckle with a small morphological opening.
        kernel = np.ones((3, 3), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

        veg_fraction = float(mask.mean())
        veg_pixels = exg[mask.astype(bool)]
        mean_greenness = float(veg_pixels.mean()) if veg_pixels.size else 0.0

        if veg_fraction < self.min_vegetation_fraction:
            label = "sparse"
        elif mean_greenness >= self.healthy_greenness:
            label = "healthy"
        else:
            label = "stressed"

        return PlantReport(
            vegetation_fraction=veg_fraction,
            mean_greenness=mean_greenness,
            health_label=label,
            mask=mask * 255,
        )

    @staticmethod
    def overlay(bgr: np.ndarray, report: PlantReport) -> np.ndarray:
        """Return a copy of the frame with the vegetation mask tinted green."""
        out = bgr.copy()
        green = np.zeros_like(out)
        green[:, :, 1] = 255
        m = report.mask.astype(bool)
        out[m] = cv2.addWeighted(out, 0.5, green, 0.5, 0)[m]
        return out
