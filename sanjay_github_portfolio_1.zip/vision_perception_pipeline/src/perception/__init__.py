"""Computer-vision perception pipeline for ground robots."""
from .obstacle_detector import Obstacle, ObstacleDetector
from .plant_analyzer import PlantAnalyzer, PlantReport
from .pipeline import FrameResult, PerceptionPipeline

__all__ = [
    "Obstacle",
    "ObstacleDetector",
    "PlantAnalyzer",
    "PlantReport",
    "FrameResult",
    "PerceptionPipeline",
]
