"""Monocular obstacle detection for ground robots.

Approximates the free-space / obstacle split a wearable assistive device or an
AMR needs from a single forward-facing camera. The approach segments the
dominant ground plane by colour/texture homogeneity in the lower image region,
then flags connected regions that rise above it as candidate obstacles.

This is a classic appearance-based free-space estimator -- lightweight enough
to run on embedded hardware without a depth sensor.
"""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np


@dataclass
class Obstacle:
    """A detected obstacle with its bounding box and image-space metrics."""

    x: int
    y: int
    w: int
    h: int
    area: int
    # Horizontal position normalised to [-1, 1] (left to right) for steering.
    bearing: float


class ObstacleDetector:
    """Detect obstacles by contrasting them against the learned ground region."""

    def __init__(
        self,
        ground_sample_height: float = 0.25,
        color_tolerance: float = 28.0,
        min_obstacle_area: int = 600,
    ) -> None:
        # Fraction of image height (from the bottom) sampled as "definitely ground".
        self.ground_sample_height = ground_sample_height
        self.color_tolerance = color_tolerance
        self.min_obstacle_area = min_obstacle_area

    def detect(
        self, bgr: np.ndarray, exclude_mask: np.ndarray | None = None
    ) -> list[Obstacle]:
        """Detect obstacles.

        ``exclude_mask`` is an optional uint8 mask (non-zero = ignore) used to
        suppress regions that should not be treated as collision obstacles --
        e.g. crop vegetation in an agriculture context.
        """
        if bgr is None or bgr.size == 0:
            raise ValueError("detect() received an empty image")

        h, w = bgr.shape[:2]
        lab = cv2.cvtColor(bgr, cv2.COLOR_BGR2LAB).astype(np.float32)

        # Learn ground appearance from a strip at the bottom-centre of the frame.
        y0 = int(h * (1.0 - self.ground_sample_height))
        x0, x1 = int(w * 0.3), int(w * 0.7)
        ground = lab[y0:h, x0:x1].reshape(-1, 3)
        mean = ground.mean(axis=0)

        dist = np.linalg.norm(lab - mean, axis=2)
        obstacle_mask = (dist > self.color_tolerance).astype(np.uint8) * 255

        if exclude_mask is not None:
            obstacle_mask[exclude_mask.astype(bool)] = 0

        # Suppress noise and close gaps inside obstacles.
        kernel = np.ones((5, 5), np.uint8)
        obstacle_mask = cv2.morphologyEx(obstacle_mask, cv2.MORPH_OPEN, kernel)
        obstacle_mask = cv2.morphologyEx(obstacle_mask, cv2.MORPH_CLOSE, kernel)

        contours, _ = cv2.findContours(
            obstacle_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )

        results: list[Obstacle] = []
        for c in contours:
            area = int(cv2.contourArea(c))
            if area < self.min_obstacle_area:
                continue
            bx, by, bw, bh = cv2.boundingRect(c)
            cx = bx + bw / 2.0
            bearing = (cx - w / 2.0) / (w / 2.0)
            results.append(Obstacle(bx, by, bw, bh, area, round(bearing, 3)))

        results.sort(key=lambda o: o.area, reverse=True)
        return results

    @staticmethod
    def draw(bgr: np.ndarray, obstacles: list[Obstacle]) -> np.ndarray:
        out = bgr.copy()
        for o in obstacles:
            cv2.rectangle(out, (o.x, o.y), (o.x + o.w, o.y + o.h), (0, 0, 255), 2)
            cv2.putText(
                out,
                f"bearing {o.bearing:+.2f}",
                (o.x, max(0, o.y - 6)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (0, 0, 255),
                1,
                cv2.LINE_AA,
            )
        return out
