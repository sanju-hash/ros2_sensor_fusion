"""Generate a synthetic crop-row scene so the demo runs with no external data.

Creates a brown soil background, a few green 'plant' blobs, and two solid
'obstacle' boxes. Real usage would feed camera frames instead.
"""
from __future__ import annotations

import os

import cv2
import numpy as np

OUT = os.path.join(os.path.dirname(__file__), "..", "sample_data", "scene.png")


def make_scene(width: int = 640, height: int = 480, seed: int = 7) -> np.ndarray:
    rng = np.random.default_rng(seed)
    img = np.zeros((height, width, 3), np.uint8)

    # Soil background (brownish), with mild noise for texture.
    img[:] = (60, 90, 130)
    noise = rng.integers(-12, 12, size=img.shape, dtype=np.int16)
    img = np.clip(img.astype(np.int16) + noise, 0, 255).astype(np.uint8)

    # Vegetation blobs (green, varying greenness to exercise health labels).
    for _ in range(14):
        cx, cy = int(rng.integers(40, width - 40)), int(rng.integers(120, height - 40))
        radius = int(rng.integers(12, 30))
        green = int(rng.integers(120, 220))
        cv2.circle(img, (cx, cy), radius, (40, green, 40), -1)

    # Two obstacles (grey box, dark post) sitting above the ground plane.
    cv2.rectangle(img, (90, 150), (180, 300), (110, 110, 110), -1)
    cv2.rectangle(img, (430, 120), (470, 320), (40, 40, 40), -1)

    img = cv2.GaussianBlur(img, (3, 3), 0)
    return img


if __name__ == "__main__":
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    cv2.imwrite(OUT, make_scene())
    print(f"wrote {os.path.abspath(OUT)}")
