"""Run the perception pipeline on an image and save an annotated result.

Usage:
    python scripts/run_demo.py                         # uses generated sample
    python scripts/run_demo.py --image path/to/img.png # uses your own image
    python scripts/run_demo.py --image 0               # live webcam (q to quit)
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import cv2

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from perception import PerceptionPipeline  # noqa: E402


def _load_sample() -> "cv2.Mat":
    from generate_sample import make_scene

    return make_scene()


def run_image(path: str | None, out_path: str) -> None:
    pipeline = PerceptionPipeline()

    if path is None:
        frame = _load_sample()
    else:
        frame = cv2.imread(path)
        if frame is None:
            raise SystemExit(f"Could not read image: {path}")

    result = pipeline.process(frame)
    annotated = pipeline.annotate(frame, result)
    cv2.imwrite(out_path, annotated)

    print(json.dumps(result.to_dict(), indent=2))
    print(f"\nAnnotated image written to: {os.path.abspath(out_path)}")


def run_webcam(index: int) -> None:
    pipeline = PerceptionPipeline()
    cap = cv2.VideoCapture(index)
    if not cap.isOpened():
        raise SystemExit(f"Could not open camera {index}")
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        result = pipeline.process(frame)
        annotated = pipeline.annotate(frame, result)
        cv2.imshow("perception", annotated)
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break
    cap.release()
    cv2.destroyAllWindows()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", default=None, help="image path, or '0' for webcam")
    parser.add_argument("--out", default="output.png", help="annotated output path")
    args = parser.parse_args()

    sys.path.insert(0, os.path.dirname(__file__))  # for generate_sample import

    if args.image is not None and args.image.isdigit():
        run_webcam(int(args.image))
    else:
        run_image(args.image, args.out)


if __name__ == "__main__":
    main()
