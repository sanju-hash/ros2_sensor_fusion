"""Tests for the perception pipeline. Run with: pytest -q"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))

from generate_sample import make_scene  # noqa: E402
from perception import (  # noqa: E402
    ObstacleDetector,
    PerceptionPipeline,
    PlantAnalyzer,
)


def test_plant_analyzer_detects_vegetation():
    scene = make_scene()
    report = PlantAnalyzer().analyze(scene)
    assert report.vegetation_fraction > 0.0
    assert report.health_label in {"healthy", "stressed", "sparse"}
    assert report.mask.shape == scene.shape[:2]


def test_obstacle_detector_finds_boxes():
    scene = make_scene()
    obstacles = ObstacleDetector().detect(scene)
    # The synthetic scene contains two large planted obstacles.
    assert len(obstacles) >= 1
    for o in obstacles:
        assert -1.0 <= o.bearing <= 1.0
        assert o.area > 0


def test_pipeline_result_serialises():
    scene = make_scene()
    result = PerceptionPipeline().process(scene)
    d = result.to_dict()
    assert "obstacle_count" in d
    assert "health_label" in d
    assert isinstance(d["obstacles"], list)


def test_empty_image_raises():
    import pytest

    with pytest.raises(ValueError):
        PlantAnalyzer().analyze(np.array([]))
