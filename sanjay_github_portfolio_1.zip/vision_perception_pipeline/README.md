# Vision Perception Pipeline

A lightweight, monocular computer-vision pipeline for ground robots. It combines
two perception tasks that recur across mobile-robot and assistive-device work:

- **Obstacle detection** — appearance-based free-space estimation from a single
  RGB camera (no depth sensor required), producing bounding boxes and a
  normalised steering *bearing* for each obstacle.
- **Plant condition analysis** — RGB vegetation segmentation using the Excess
  Green (ExG) index, with a coarse health label (`healthy` / `stressed` /
  `sparse`) suited to precision-agriculture row inspection.

Both run per-frame and combine into a single annotated image plus a structured,
JSON-serialisable result that a navigation or control layer can consume.

> Background: this consolidates perception work from an MSc precision-agriculture
> AMR (LiDAR/IMU sensor fusion, SLAM, crop analysis) and an undergraduate
> assistive wearable for the visually impaired (real-time obstacle feedback).

## Demo

No external data needed — a synthetic crop-row scene is generated on the fly:

```bash
pip install -r requirements.txt
python scripts/run_demo.py
```

This prints a result like:

```json
{
  "obstacle_count": 2,
  "obstacles": [
    { "x": 91, "y": 151, "w": 89, "h": 149, "area": 13024, "bearing": -0.577 }
  ],
  "vegetation_fraction": 0.0609,
  "mean_greenness": 0.9292,
  "health_label": "healthy"
}
```

and writes an annotated `output.png` (red obstacle boxes with steering bearings,
green vegetation overlay).

Run on your own image or a live webcam:

```bash
python scripts/run_demo.py --image path/to/image.png
python scripts/run_demo.py --image 0          # webcam, press q to quit
```

## How it works

**Obstacle detection** samples a strip of "definitely ground" from the
bottom-centre of the frame, learns its mean colour in CIELAB space, then flags
connected regions that differ beyond a tolerance. Each region's horizontal
centre is mapped to a bearing in `[-1, 1]` (left to right) for downstream
steering. This is a classic appearance-based estimator — cheap enough for
embedded hardware and robust to lighting when re-sampled per frame.

**Plant analysis** computes Excess Green (`2g − r − b` on chromatic-normalised
channels), thresholds it into a vegetation mask, cleans speckle with a
morphological opening, then derives a health label from the vegetated fraction
and mean greenness.

## Project layout

```
src/perception/
  obstacle_detector.py   # appearance-based obstacle detection
  plant_analyzer.py      # ExG vegetation index + health label
  pipeline.py            # orchestrates both, annotates frames
scripts/
  run_demo.py            # CLI: image / sample / webcam
  generate_sample.py     # synthetic crop-row scene
tests/
  test_pipeline.py       # pytest suite
```

## Tests

```bash
pytest -q
```

## Notes & extensions

- The obstacle detector is intentionally appearance-based; with a depth camera
  or stereo pair, swap in a disparity-based ground-plane fit for metric ranges.
- For true NDVI, add a near-infrared channel — ExG is the RGB-only approximation.
- Designed to drop into a ROS 2 node: wrap `PerceptionPipeline.process()` in a
  subscriber callback on an image topic and publish the `FrameResult`.

## License

MIT — see [LICENSE](LICENSE).
