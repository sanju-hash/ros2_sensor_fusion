# Hi, I'm Sanjay Kumar 👋

**Robotics Software Engineer** — autonomous systems, perception, and control,
backed by production software-engineering experience.

MSc Robotics (Heriot-Watt University, Edinburgh). I build the full autonomy
stack: perception → localization → navigation, with ROS 2 and modern C++/Python,
and I bring scalable Java/Spring Boot backend experience from industry.

🔭 Currently seeking robotics / software engineering roles (open to relocation —
Germany 🇩🇪 / Netherlands 🇳🇱 / EU).

---

### 🤖 What I work on

- **Perception** — computer vision pipelines, sensor processing, obstacle detection
- **Localization** — EKF sensor fusion (LiDAR, IMU, wheel odometry), SLAM
- **Navigation & control** — path tracking, motion planning for mobile robots
- **Backend** — Java Spring Boot microservices, REST APIs, CI/CD

### 🛠️ Tech

`ROS 2` · `Python` · `C++` · `OpenCV` · `NumPy` · `SLAM` · `Sensor Fusion`
`Java` · `Spring Boot` · `Linux` · `MATLAB` · `Git`

### 📌 Featured projects

| Project | What it is |
|---------|-----------|
| [**ROS 2 Sensor Fusion**](https://github.com/<your-username>/ros2_sensor_fusion) | EKF fusing wheel odometry + IMU for 2D localization. NumPy core + `rclpy` node + hardware-free simulator. |
| [**Vision Perception Pipeline**](https://github.com/<your-username>/vision_perception_pipeline) | Monocular obstacle detection + crop-health analysis for ground robots. Runs on image/webcam out of the box. |
| [**ROS 2 Waypoint Navigation**](https://github.com/<your-username>/ros2_waypoint_nav) | Pure-pursuit path tracking for a differential-drive robot, with a kinematic simulator. |

### 📫 Reach me

- 📧 sanjayshekhar2000@gmail.com
- 💼 [LinkedIn](https://www.linkedin.com/in/<your-linkedin>)

<!--
Tip: this README lives in a repository named exactly after your username.
Create a repo called  <your-username>  and put this file in it as README.md
to make it show up on your profile page.
-->
