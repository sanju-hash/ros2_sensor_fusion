# GitHub Setup & Push Guide

Everything here is built, tested, and ready to push. Follow these steps in
order. Replace `<your-username>` everywhere with the GitHub username you choose.

---

## Step 1 — Create your GitHub account (you do this)

I can't create the account for you — it needs your password and a CAPTCHA.

1. Go to **https://github.com/signup**
2. Use your email: **sanjayshekhar2000@gmail.com**
3. Pick a username. Suggestions: `sanjaykumar-robotics`, `sanjay-shekhar`,
   `sanjayk-dev`. **Keep it professional — recruiters see it.**
4. Verify your email.

## Step 2 — Install Git and authenticate (one time)

```bash
# Linux
sudo apt install git gh

# macOS
brew install git gh

# then log in (opens a browser, no password typed in terminal)
gh auth login
```

Set your identity:

```bash
git config --global user.name "Sanjay Kumar"
git config --global user.email "sanjayshekhar2000@gmail.com"
```

## Step 3 — Push the three project repos

For **each** of the three folders (`ros2_sensor_fusion`,
`vision_perception_pipeline`, `ros2_waypoint_nav`), do this from inside the
folder:

```bash
cd ros2_sensor_fusion          # repeat for each project folder

git init
git add .
git commit -m "Initial commit: EKF sensor fusion package"

# Create the GitHub repo and push in one go (needs gh from step 2):
gh repo create ros2_sensor_fusion --public --source=. --push
```

Repeat with the matching name and message for the other two:

```bash
cd ../vision_perception_pipeline
git init && git add . && git commit -m "Initial commit: vision perception pipeline"
gh repo create vision_perception_pipeline --public --source=. --push

cd ../ros2_waypoint_nav
git init && git add . && git commit -m "Initial commit: pure-pursuit waypoint navigation"
gh repo create ros2_waypoint_nav --public --source=. --push
```

> No `gh`? Create each repo manually on github.com (the **+** menu → New
> repository, same name, Public, **don't** add a README), then:
> ```bash
> git remote add origin https://github.com/<your-username>/ros2_sensor_fusion.git
> git branch -M main
> git push -u origin main
> ```

## Step 4 — Set up your profile README

This is the page visitors see on your profile. It lives in a repo named
**exactly** your username.

1. Create a new **public** repo named `<your-username>` (identical to your
   username — GitHub will show a "special repository" note, that's correct).
2. Put the `profile/README.md` file in it:

```bash
cd ../profile
git init
git add README.md
git commit -m "Add profile README"
gh repo create <your-username> --public --source=. --push
```

3. Open `README.md` first and replace the `<your-username>` and
   `<your-linkedin>` placeholders with your real handles.

## Step 5 — Polish (optional but worth it)

- Add **topics** to each repo (e.g. `ros2`, `robotics`, `computer-vision`,
  `ekf`, `slam`) — recruiters and GitHub search use these.
- Add a short **description** in each repo's "About" section.
- Pin the three repos on your profile (profile page → Customize your pins).
- Add your GitHub URL to your CV and LinkedIn.

---

## What's in each project

**ros2_sensor_fusion** — EKF fusing odometry + IMU. Filter core is pure NumPy
and passes 4 unit tests (`pytest test/`); `rclpy` node + simulator run via
`ros2 launch sensor_fusion fusion.launch.py`.

**vision_perception_pipeline** — runs immediately with `python scripts/run_demo.py`
(no ROS needed); generates a sample scene, detects obstacles with steering
bearings, classifies crop health, writes an annotated image. 4 unit tests pass.

**ros2_waypoint_nav** — pure-pursuit waypoint follower + kinematic simulator;
`ros2 launch waypoint_nav nav.launch.py`. Controller core passes 4 unit tests.

All three are MIT-licensed and have their own README.

---

### A note on honesty in interviews

These are real, working implementations of techniques you list on your CV — but
make sure you can **explain and extend every one** before pushing them. Read
through the code, run the tests, tweak a parameter and see what changes. In a
robotics interview you'll likely be asked to walk through the EKF predict/update
steps or the pure-pursuit curvature math — owning that understanding is what
turns a portfolio into an offer.
