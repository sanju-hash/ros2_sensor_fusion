"""Pure-pursuit path tracking for a differential-drive robot.

Given the robot pose and an ordered list of waypoints, the controller selects a
lookahead point along the path and computes the linear and angular velocity
commands that steer the robot toward it. Plain NumPy, no ROS dependency.

Reference: Coulter (1992), "Implementation of the Pure Pursuit Path Tracking
Algorithm".
"""
from __future__ import annotations

import math
from dataclasses import dataclass


def wrap_angle(a: float) -> float:
    return (a + math.pi) % (2.0 * math.pi) - math.pi


@dataclass
class Command:
    v: float       # linear velocity (m/s)
    omega: float   # angular velocity (rad/s)


class PurePursuit:
    def __init__(
        self,
        lookahead: float = 0.5,
        max_v: float = 0.6,
        max_omega: float = 1.5,
        goal_tolerance: float = 0.15,
    ) -> None:
        self.lookahead = lookahead
        self.max_v = max_v
        self.max_omega = max_omega
        self.goal_tolerance = goal_tolerance
        self.waypoints: list[tuple[float, float]] = []
        self._idx = 0

    def set_path(self, waypoints: list[tuple[float, float]]) -> None:
        self.waypoints = list(waypoints)
        self._idx = 0

    @property
    def finished(self) -> bool:
        return self._idx >= len(self.waypoints)

    def _advance_target(self, x: float, y: float) -> None:
        """Skip intermediate waypoints already within the lookahead radius.

        The final waypoint is never skipped here -- it is only consumed once the
        robot is within ``goal_tolerance`` (handled in ``compute``).
        """
        while self._idx < len(self.waypoints) - 1:
            wx, wy = self.waypoints[self._idx]
            if math.hypot(wx - x, wy - y) < self.lookahead:
                self._idx += 1
            else:
                break

    def compute(self, x: float, y: float, theta: float) -> Command:
        if self.finished:
            return Command(0.0, 0.0)

        self._advance_target(x, y)
        if self.finished:
            return Command(0.0, 0.0)

        # Stop when the final waypoint is within tolerance.
        gx, gy = self.waypoints[-1]
        if (
            self._idx == len(self.waypoints) - 1
            and math.hypot(gx - x, gy - y) < self.goal_tolerance
        ):
            self._idx = len(self.waypoints)
            return Command(0.0, 0.0)

        tx, ty = self.waypoints[self._idx]

        # Transform target into the robot frame.
        dx, dy = tx - x, ty - y
        local_x = math.cos(-theta) * dx - math.sin(-theta) * dy
        local_y = math.sin(-theta) * dx + math.cos(-theta) * dy

        dist = math.hypot(local_x, local_y)
        if dist < 1e-6:
            return Command(0.0, 0.0)

        # Pure-pursuit curvature: kappa = 2*y / L^2.
        curvature = 2.0 * local_y / (dist * dist)

        v = self.max_v
        omega = curvature * v

        # Slow down for sharp turns; clamp to limits.
        if abs(omega) > self.max_omega:
            scale = self.max_omega / abs(omega)
            v *= scale
            omega = math.copysign(self.max_omega, omega)

        return Command(v, omega)
