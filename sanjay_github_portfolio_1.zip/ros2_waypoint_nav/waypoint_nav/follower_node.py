"""ROS 2 waypoint-follower node using pure-pursuit control.

Subscribes:
    /odom  (nav_msgs/Odometry)   current robot pose

Publishes:
    /cmd_vel (geometry_msgs/Twist)   velocity command

Waypoints are loaded from the `waypoints` parameter (flat list
[x0, y0, x1, y1, ...]).
"""
from __future__ import annotations

import math

import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.node import Node

from .pure_pursuit import PurePursuit


def yaw_from_quaternion(z: float, w: float) -> float:
    return math.atan2(2.0 * w * z, 1.0 - 2.0 * z * z)


class WaypointFollower(Node):
    def __init__(self) -> None:
        super().__init__("waypoint_follower")

        self.declare_parameter("lookahead", 0.5)
        self.declare_parameter("max_v", 0.6)
        self.declare_parameter("max_omega", 1.5)
        self.declare_parameter("goal_tolerance", 0.15)
        self.declare_parameter("waypoints", [1.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0])

        self.controller = PurePursuit(
            lookahead=self.get_parameter("lookahead").value,
            max_v=self.get_parameter("max_v").value,
            max_omega=self.get_parameter("max_omega").value,
            goal_tolerance=self.get_parameter("goal_tolerance").value,
        )
        flat = self.get_parameter("waypoints").value
        waypoints = [(flat[i], flat[i + 1]) for i in range(0, len(flat), 2)]
        self.controller.set_path(waypoints)
        self.get_logger().info(f"Loaded {len(waypoints)} waypoints")

        self.create_subscription(Odometry, "odom", self._on_odom, 10)
        self.cmd_pub = self.create_publisher(Twist, "cmd_vel", 10)
        self._done_logged = False

    def _on_odom(self, msg: Odometry) -> None:
        p = msg.pose.pose
        x, y = p.position.x, p.position.y
        theta = yaw_from_quaternion(p.orientation.z, p.orientation.w)

        cmd = self.controller.compute(x, y, theta)
        twist = Twist()
        twist.linear.x = cmd.v
        twist.angular.z = cmd.omega
        self.cmd_pub.publish(twist)

        if self.controller.finished and not self._done_logged:
            self.get_logger().info("Goal reached -- path complete")
            self._done_logged = True


def main(args=None) -> None:
    rclpy.init(args=args)
    node = WaypointFollower()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
