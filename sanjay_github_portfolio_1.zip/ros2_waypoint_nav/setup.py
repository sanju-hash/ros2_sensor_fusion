from setuptools import find_packages, setup

package_name = "waypoint_nav"

setup(
    name=package_name,
    version="0.1.0",
    packages=find_packages(exclude=["test"]),
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
        ("share/" + package_name, ["package.xml"]),
        ("share/" + package_name + "/launch", ["launch/nav.launch.py"]),
        ("share/" + package_name + "/config", ["config/waypoints.yaml"]),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="Sanjay Kumar",
    maintainer_email="sanjayshekhar2000@gmail.com",
    description="Pure-pursuit waypoint navigation for a differential-drive robot.",
    license="MIT",
    entry_points={
        "console_scripts": [
            "follower_node = waypoint_nav.follower_node:main",
            "sim_node = waypoint_nav.sim_node:main",
        ],
    },
)
