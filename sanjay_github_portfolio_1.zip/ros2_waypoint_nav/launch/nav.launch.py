"""Launch the simulator and the pure-pursuit waypoint follower."""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    config = os.path.join(
        get_package_share_directory("waypoint_nav"), "config", "waypoints.yaml"
    )
    return LaunchDescription(
        [
            Node(
                package="waypoint_nav",
                executable="sim_node",
                name="diffdrive_sim",
                output="screen",
            ),
            Node(
                package="waypoint_nav",
                executable="follower_node",
                name="waypoint_follower",
                output="screen",
                parameters=[config],
            ),
        ]
    )
