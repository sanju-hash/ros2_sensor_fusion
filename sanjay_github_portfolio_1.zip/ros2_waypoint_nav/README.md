# ROS 2 Waypoint Navigation (Pure Pursuit)

A ROS 2 package that drives a differential-drive robot through an ordered list
of waypoints using the **pure-pursuit** path-tracking algorithm. The controller
core is plain Python (no ROS dependency), so it is unit-testable and reusable;
a `rclpy` node wraps it, and a bundled kinematic simulator lets the whole thing
run with no hardware.

## What it does

Given the robot's pose and a path, pure pursuit picks a lookahead point along
the path and computes the curvature — and hence the `(v, omega)` command — that
steers the robot toward it. Velocity is reduced for sharp turns and clamped to
configurable limits.

## Topics

| Direction | Topic       | Type                    |
|-----------|-------------|-------------------------|
| sub       | `/odom`     | `nav_msgs/Odometry`     |
| pub       | `/cmd_vel`  | `geometry_msgs/Twist`   |

## Quick start

```bash
mkdir -p ~/ws/src && cd ~/ws/src
git clone https://github.com/<your-username>/ros2_waypoint_nav.git waypoint_nav
cd ~/ws
colcon build --packages-select waypoint_nav
source install/setup.bash
ros2 launch waypoint_nav nav.launch.py
```

The default path is a 1 m square loop. Watch the follower log `Goal reached`
once complete, or echo the commands:

```bash
ros2 topic echo /cmd_vel
```

## Configuration

Edit `config/waypoints.yaml` (or override on the command line). Waypoints are a
flat `[x0, y0, x1, y1, ...]` list:

```yaml
waypoint_follower:
  ros__parameters:
    lookahead: 0.5
    max_v: 0.6
    max_omega: 1.5
    goal_tolerance: 0.15
    waypoints: [1.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0]
```

## Tests

```bash
pytest test/ -q
```

Covered: reaching a single goal, completing a multi-segment square loop within
tolerance, command limit clamping, and empty-path handling.

## Design notes

- **Lookahead** trades smoothness for corner-cutting: larger values give
  smoother motion but wider turns.
- The final waypoint is only consumed inside `goal_tolerance`, so the robot
  drives all the way onto the goal rather than stopping a lookahead short.
- Pairs naturally with the [EKF sensor-fusion](../ros2_sensor_fusion) package:
  feed its `/odom_filtered` in as the pose source for closed-loop navigation.

## License

MIT — see [LICENSE](LICENSE).
