"""Tests for the pure-pursuit controller. Run with: pytest -q  (no ROS needed)"""
import math
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from waypoint_nav.pure_pursuit import PurePursuit, wrap_angle  # noqa: E402


def _simulate(waypoints, dt=0.05, max_steps=3000):
    ctrl = PurePursuit(lookahead=0.4, max_v=0.6, max_omega=1.5, goal_tolerance=0.15)
    ctrl.set_path(waypoints)
    x = y = theta = 0.0
    steps = 0
    while not ctrl.finished and steps < max_steps:
        cmd = ctrl.compute(x, y, theta)
        x += cmd.v * math.cos(theta) * dt
        y += cmd.v * math.sin(theta) * dt
        theta = wrap_angle(theta + cmd.omega * dt)
        steps += 1
    return ctrl, (x, y), steps


def test_reaches_single_goal():
    ctrl, (x, y), _ = _simulate([(2.0, 0.0)])
    assert ctrl.finished
    assert math.hypot(x - 2.0, y - 0.0) < 0.15


def test_completes_square_loop():
    wps = [(1.0, 0.0), (1.0, 1.0), (0.0, 1.0), (0.0, 0.0)]
    ctrl, (x, y), steps = _simulate(wps)
    assert ctrl.finished
    assert math.hypot(x - 0.0, y - 0.0) < 0.2
    assert steps < 3000


def test_commands_respect_limits():
    ctrl = PurePursuit(max_v=0.6, max_omega=1.5)
    ctrl.set_path([(0.0, 2.0)])  # target straight to the side -> sharp turn
    cmd = ctrl.compute(0.0, 0.0, 0.0)
    assert cmd.v <= 0.6 + 1e-9
    assert abs(cmd.omega) <= 1.5 + 1e-9


def test_empty_path_is_finished():
    ctrl = PurePursuit()
    ctrl.set_path([])
    assert ctrl.finished
    cmd = ctrl.compute(0.0, 0.0, 0.0)
    assert cmd.v == 0.0 and cmd.omega == 0.0
